## Returns the supported API versions and the internal build nr

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/about' \
  -H 'accept: application/json'
```

## List all downloaded attachments

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/attachments' \
  -H 'accept: application/json'
```

## Serve the attachment with the given id

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/attachments/{attachment}' \
  -H 'accept: application/json'
```

## List the REST API configuration.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/configuration' \
  -H 'accept: application/json'
```

## List account specific settings.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/configuration/+61422635661/settings' \
  -H 'accept: application/json'
```

## Updates the info associated to a number on the contact list.

```sh
curl -X 'PUT' \
  'http://192.168.1.104:8080/v1/+contacts/+61422635661' \
  -H 'accept: application/json'
```

## Links another device to this device. Only works, if this is the master device.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/devices/+61422635661' \
  -H 'accept: application/json'
```

## List all Signal Groups.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/groups/+61422635661' \
  -H 'accept: application/json'
```

## List a specific Signal Group.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/groups/+61422635661/{groupid}' \
  -H 'accept: application/json'
```

## Add one or more admins to an existing Signal Group.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/groups/+61422635661/{groupid}/admins' \
  -H 'accept: application/json'
```

## Block the specified Signal Group.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/groups/+61422635661/{groupid}/block' \
  -H 'accept: application/json'
```

## Join the specified Signal Group.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/groups/+61422635661/{groupid}/join' \
  -H 'accept: application/json'
```

## Add one or more members to an existing Signal Group.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/groups/+61422635661/{groupid}/members' \
  -H 'accept: application/json'
```

## Quit the specified Signal Group.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/groups/+61422635661/{groupid}/quit' \
  -H 'accept: application/json'
```

## Internally used by the docker container to perform the health check.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/health' \
  -H 'accept: application/json'
```

## List all identities for the given number.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/identities/+61422635661' \
  -H 'accept: application/json'
```

## Trust an identity. When 'trust_all_known_keys' is set to' true', all known keys of this user are trusted. **This is onlrecommended for testing.**",

```sh
curl -X 'PUT' \
  'http://192.168.1.104:8080/v1/identities/+61422635661/trust/{numberToTrust}' \
  -H 'accept: application/json'
```

## Set your name and optional an avatar.

```sh
curl -X 'PUT' \
  'http://192.168.1.104:8080/v1/profiles/+61422635661' \
  -H 'accept: application/json'
```

## Link device and generate QR code

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/qrcodelink' \
  -H 'accept: application/json'
```

## React to a message

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/reactions/+61422635661' \
  -H 'accept: application/json'
```

Receives Signal Messages from the Signal Network. If you are running the docker container in normal/native mode, this is a ## GEendpoint. In json-rpc mode this is a websocket endpoint.",

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/receive/+61422635661' \
  -H 'accept: application/json'
```

## Register a phone number with the signal network.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/register/+61422635661' \
  -H 'accept: application/json'
```

## Verify a registered phone number with the signal network.

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/register/+61422635661/verify/{token}' \
  -H 'accept: application/json'
```

## Check if one or more phone numbers are registered with the Signal Service.

```sh
curl -X 'GET' \
  'http://192.168.1.104:8080/v1/search' \
  -H 'accept: application/json'
```

## Send a signal message

```sh
 curl -X POST -H "Content-Type: application/json" 'http://localhost:8080/v2/send' \
     -d '{"message": "Test via Signal API!", "number": "+61422635661", "recipients": [ "+61422635661" ]}'
```

## Show Typing Indicator.

```sh
curl -X 'PUT' \
  'http://192.168.1.104:8080/v1/typing-indicator/+61422635661' \
  -H 'accept: application/json'
```

## Disables push support for this device. **WARNING:** If *delete_account* is set to *true*, the account will be deleted from thSignal Server. This cannot be undone without loss.",

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v1/unregister/+61422635661' \
  -H 'accept: application/json'
```

## Send a signal message

```sh
curl -X 'POST' \
  'http://192.168.1.104:8080/v2/send' \
  -H 'accept: application/json'
```
