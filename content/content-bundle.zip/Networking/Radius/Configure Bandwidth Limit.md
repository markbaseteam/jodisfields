# Configure Bandwidth Limit

---

## Log into Daloradius

Open a browser and go to your Daloradius panel then open the Profiles page.

Navigate to the Profiles page and click on the **New Profile** option. We’re going to create a profile that allows only 1 connection, so I’ve named it “_OneDevice”_. You can name it whatever you want.

**[![](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/add_profile_1-e1548350569586.jpg&nocache=1)](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/add_profile_1-e1548350569586.jpg&nocache=1)**

---

## Limit simultaneous sessions

One of the most important features of FreeRadius is the attribute. We can use attributes to define what a user can or cannot do, create dynamic rules to decide if a user can be authenticated.

In our example, we’re going to set the maximum simultaneous sessions to 1 for the users assigned to our new profile.

Click on the **Quickly Locate attribute with autocomplete checkbox** and type **Simultaneous-Use**[![](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/add_atttribute_simoultaneous-1.jpg&nocache=1)](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/add_atttribute_simoultaneous-1.jpg&nocache=1)

The autocomplete will suggest the **Simultaneous-Use** attribute. Select it and click  **Add Attribute.**

Set the value to the maximum number of sessions. I’m going to set it to 1. Make sure that the operator is set to “**:=**” and the attribute target is “**check**”

[![](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/attribute_ad.jpg&nocache=1)](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/attribute_ad.jpg&nocache=1)

---

## Set accounting intervals

Repeat the instructions from step 3 in order to add another attribute.  This time, we’re going to add to the profile the “**Acct-Interim-Interval**“.

Unlike the Simultaneous attribute, this one’s target must be set to **reply.** It sets the interval for accounting updates. A value of 600 means that the client app will send to the radius server accounting updates about the user every 600 seconds.

[![](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/reply_attributes.jpg&nocache=1)](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/reply_attributes.jpg&nocache=1)

---

## Limit the monthly bandwidth

For the first two rules, we have used the default Freeradius attributes. In order to set a bandwidth monthly quota, we need to create a custom attribute. This process can be used to create any custom accounting condition, using sqlcounter.

Open an SSH session to your radius server and follow the steps below.

```sh
cd /etc/freeradius/3.0/mods-enabled
ln -s ../mods-available/sqlcounter sqlcounter
```

Edit the sqlcounter. The settings below create a new custom attribute that checks the bandwidth for the last 30 days.

```sh
#define a new sqlcounter
sqlcounter monthly_limit{
	counter_name = 'Max-Total-Bandwidth' #define an attribute name. we will add this in daloRadius Profile
	check_name = 'Monthly-Bandwidth'
	sql_module_instance = sql
	key = 'User-Name'
	dialect = mysql
	reset = 30
	query = "SELECT SUM(acctinputoctets) + SUM(acctoutputoctets) FROM
	radacct WHERE UserName='%{${key}}'"
}
```

The sqlcounter is now defined! In the next step, we will add it to our Freeradius config file, under **authorize.**

```sh
nano /etc/freeradius/3.0/sites-available/default
```

```sh
authorize {
	daily_limit    # There will be other config here, we are adding an additional parameter
}
```

```sh
service freeradius reload
```

The custom attribute is now ready to be added to our profile from Daloradius like we did the previous steps. In the example below, the limit is set around **12GB**.

[![](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/monthlylimit.jpg&nocache=1)](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/monthlylimit.jpg&nocache=1)

---

## Create a user with the profile

When creating a new user, the profile can be selected from the **Group** dropdown. Now, all the attributes defined in the profile will apply to the user. Any changes done to the profile attributes will instantly apply to the member users of that group.

[![](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/add_user.jpg&nocache=1)](https://draculaservers.com/tutorials/wp-content/webpc-passthru.php?src=https://draculaservers.com/tutorials/wp-content/uploads/2019/01/add_user.jpg&nocache=1)

## Troubleshooting

Adding a new attribute and editing the Freeradius config files might generate some errors if we’re not careful. Here are some of the more common ones:

> [!Error]
> #### Failed to create the pair: Unknown name
>---
> **Fix**: Make sure you’ve added the newly created sqlcounter name in the **_default_** _configuration file._ 

> [!Error]
> #### Reference ```{modules.sql.dialect}``` not found
>---
> **Fix**: This one is caused by a Freeradius bug. In order to make it go away, you must specify the dialect of the database in the sqlcouter