# Disable TCP Optimizations - AVI

  

## Symptom:

  

An IOS-based ESR router (5921) may see TCP performance degradation when the host-side linux interfaces have driver optimizations enabled. More notably, having generic-receive-offload (GRO) enabled.

  

## How to check if GRO is enabled:

  

To view the current optimizations applied to the linux interfaces, follow the steps below:

  

1. Log into the linux environment on your AVI device via console or SSH.

  

2. Run the following command to create a file called **avi-check.sh**.

  

```bash
touch avi-check.sh
```

  

3. Edit the new file using nano - a text editor for the terminal.

  

```bash
nano avi-check.sh
```

  

4. Copy and paste the following code into the file.

  

```bash
#!/bin/bash
for int in $(ifconfig | grep flags | grep -v LOOPBACK | awk -F':' '{print $1}'); do
ethtool --show-features $int | grep -E 'Features|generic-receive-offload'
done
```

  

5. Save the file and exit nano by pressing **CTRL+X**, then press **Y** to save the file and **ENTER** to confirm the filename.

  

6. Run the following command to make the file executable.

  

```bash
chmod +x avi-check.sh
```

7. Run the following command to execute the file.

  

```bash
./avi-check.sh
```

  

8. The output should look similar to the following:

  

```bash
Features for br-76438e1e9d80:
generic-receive-offload: on

Features for docker0:
generic-receive-offload: on

Features for enp5s0:
generic-receive-offload: on
```

  

## How to disable the driver optimizations:

  

To disable the driver optimizations, follow the steps below:

  

1. Log into the linux environment on your AVI device via console or SSH.

  

2. Run the following command to create a file called **avi-disable.sh**.

  

```bash
touch avi-disable.sh
```

  

3. Edit the new file using nano - a text editor for the terminal.

  

```bash
nano avi-disable.sh
```

  

4. Copy and paste the following code into the file.

  

```bash
#!/bin/bash
for int in $(ifconfig | grep flags | grep -v LOOPBACK | awk -F':' '{print $1}'); do
ethtool -K $int rx off tx off sg off tso off gso off gro off > /dev/null
ethtool --show-features $int | grep -E 'Features|generic-receive-offload'
done
```

  

5. Save the file and exit nano by pressing **CTRL+X**, then press **Y** to save the file and **ENTER** to confirm the filename.

  

6. Run the following command to make the file executable.

  

```bash
chmod +x avi-disable.sh
```

  

7. Run the following command to execute the file.

  

```bash
./avi-disable.sh
```

  

8. The output should look similar to the following:

  

```bash
Features for br-76438e1e9d80:
generic-receive-offload: off

Features for docker0:
generic-receive-offload: off

Features for enp5s0:
generic-receive-offload: off
```

  

## How to make the changes persistent:

  

To make the changes persistent, follow the steps below:

  

1. Log into the linux environment on your AVI device via console or SSH.

  

2. Run the following command to create a file called **avi-disable.service**.

  

```bash
touch /etc/systemd/system/avi-disable.service
```

  

3. Edit the new file using nano - a text editor for the terminal.

  

```bash
nano /etc/systemd/system/avi-disable.service
```

  

4. Copy and paste the following code into the file.

  

```bash
[Unit]
Description=Disable AVI TCP driver optimizations

[Service]
Type=oneshot
ExecStart=/root/avi-disable.sh

[Install]
WantedBy=multi-user.target
```

  

5. Save the file and exit nano by pressing **CTRL+X**, then press **Y** to save the file and **ENTER** to confirm the filename.

  

6. Run the following command to enable the service.

  

```bash
systemctl enable avi-disable.service
```

  

7. Run the following command to start the service.

  

```bash
systemctl start avi-disable.service
```

  

8. Run the following command to check the status of the service.

  

```bash
systemctl status avi-disable.service
```

  

9. The output should look similar to the following:

  

```bash
avi-disable.service - Disable AVI TCP driver optimizations
Loaded: loaded (/etc/systemd/system/avi-disable.service; enabled; vendor preset: enabled)

Active: active (exited) since Fri 2021-03-19 15:38:05 UTC; 1min 5s ago
Process: 1003 ExecStart=/root/avi-disable.sh (code=exited,status=0/SUCCESS)
Main PID: 1003 (code=exited, status=0/SUCCESS)
```

  

10. To check the service logs, run:

  

```bash
journalctl -u avi-disable.service
```