# Generic Receive Offload (GRO)

Generic Receive Offload (GRO) is a widely used SW-based offloading technique to reduce per-packet processing overhead. **This is achieved by reassembling small packets into larger ones, GRO enables applications to process fewer large packets directly, thus reducing the number of packets to be processed**. To benefit DPDK-based applications, like Open vSwitch, DPDK also provides own GRO implementation. In DPDK, GRO is implemented as a standalone library. Applications explicitly use the GRO library to reassemble packets.

---

## Overview
- In the GRO library, **there are many GRO types which are defined by packet types**. One GRO type is in charge of processing one type of packet. For example, TCP/IPv4 GRO processes TCP/IPv4 packets.
- Each GRO type has a reassembly function, **which defines its own algorithm and table structure to reassemble packets**. We assign input packets to the corresponding GRO functions by MBUF->packet_type.
- The GRO library doesn’t check if input packets have correct checksums and **doesn’t re-calculate checksums for merged packets. The GRO library assumes the packets are complete even when IP fragmentation is possible**. Additionally, it complies RFC 6864 to process the IPv4 ID field.
- Currently, the GRO library provides **GRO supports for TCP/IPv4 and UDP/IPv4 packets** as well as VxLAN packets which contain an outer IPv4 header and an inner TCP/IPv4 or UDP/IPv4 packet.

---

## Reassembly Algorithm
The reassembly algorithm is used for reassembling packets. In the GRO library, different GRO types can use different algorithms. In this section, we will introduce the algorithm used by TCP/IPv4 and VxLAN GRO.

### Challenges
The reassembly algorithm determines the efficiency of GRO. There are two main challenges in the algorithm design:

1. Implementing such a high cost algorithm could **cause dropped packets in high speed networks**.
2. Packet reordering makes it hard to merge packets. For example, **Linux GRO fails to merge packets when it encounters packet reordering**.

---

## GRO Library Limitations
- GRO library uses MBUF->l2_len/l3_len/l4_len/outer_l2_len/ outer_l3_len/packet_type to get protocol headers for the input packet, rather than parsing the packet header. Therefore, before call GRO APIs to merge packets, user applications must set MBUF->l2_len/l3_len/l4_len/outer_l2_len/outer_l3_len/ packet_type to the same values as the protocol headers of the packet.
- GRO library **doesn’t support packets with IPv4 Options or VLAN tagging**.
- GRO library just only supports packets that are organized in a single MBUF. **If the input packet consists of multiple MBUFs (i.e. chained MBUFs), GRO reassembly behaviors are unknown**.

---

## What are MBUFs
The MBUF (short for memory buffer) is a common concept in networking stacks. **The MBUF is used to hold packet data as it traverses the stack. The MBUF also generally stores header information or other networking stack information that is carried around with the packet**. The MBUF and its associated library of functions were developed to make common networking stack operations like stripping and adding protocol headers as efficient and copy-free as possible.

In its simplest form, **an MBUF is a memory block with some space reserved for internal information and a pointer which is used to "chain" memory blocks together in order to create a "packet"**. This is a very important aspect of the MBUF: the ability to chain MBUFS together to create larger "packets" (chains of MBUFS).