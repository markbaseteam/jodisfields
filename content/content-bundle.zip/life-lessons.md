
- It’s ok to say, “I don’t know” because it’s impossible to have all the answers. The older I get the more I realize knowledge is practically infinite and I don’t know that much.

- Never underestimate the power of being the first to truly believe in someone.

- Everything rises and passes. It’s a law of nature. Change is constant around us and within us.

- Don’t always trust your feelings and snap judgements about others. We’re very good at crafting stories and beliefs in our minds with very little information and context.

- Every person is likely struggling with something. Be kind. Be helpful.

- Don’t buy something just to buy it. Accumulation of things will never lead to sustained happiness.

- When we speak openly about our challenges it can give others the strength and courage to do the same.

- Time is the single most important non-renewable resource we all have. Fill your days with what truly brings you alive, fills you with energy and allows you to grow.

- The only person you can change is yourself. It is nearly impossible to change other people. However, when they notice your own change, it might give them the courage or impetus to change themselves.

- Being a parent is 5x harder but 100x more enjoyable and fulfilling than I ever imagined. Love for a child is boundless. Caring for your child is the purpose of life.

- If you want to make progress on the things that matter most, you need to decide who you’re going to disappoint. It’s inevitable.

- Real trust and deep relationships can’t be manufactured or rushed. These are built over time through countless authentic and meaningful interactions and experiences.

- Traveling is single most effective way to learn about yourself, humanity and the world.

- Most of the time, family and friends don’t need you to fix their problems, they just need you to be there with them.

- We are all far more powerful, resilient and adaptive than we even realize. It’s never too late to change and remake yourself. We are all a work in progress.

- Equanimity isn’t suppression of thoughts or feelings but rather being ok with how a situation unfolds or how we feel in a given moment.

- Meditation is surest path to understanding yourself, your feelings, your thoughts and your perceptions.

- If you wait for the perfect moment or inspiration to learn a new craft or create something, you’ll never progress. Start now if it’s truly burning within you or else you’ll be exactly in the same place ten years from now.

- Listening with your eyes is just as powerful as listening with your ears.

- Living a sober life is vastly more enjoyable and liberating than society wants you to believe. You can have fun and be social without substances.

- Every single one of us has a different map of the world. So if you want to understand someone then you have to understand their map.

- Don’t force things. Apply the just right amount of effort but not too much.

- Being uncomfortable will take you to your edge and that’s where real growth and transformation happens.

- How you spend your time and your calendar reflects what you truly value in life.

- Pick your spots. We have limited time and our brains can only process so much. Focus is key. Choose wisely.

- A great teammate always puts the organization and its purpose ahead of their own self interests.

- Admit when you’re wrong and/or being an asshole. And when you are, learn from those experiences.

- You can’t be everything to everyone so might as well be yourself. Follow your values.

- All relationships, even the healthiest ones, are difficult and complex because most humans aren’t ‘compatible.’ The key to making them work is open communication, patience and compromise.

- You can likely learn the fundamentals any topic or craft if you dedicate ~100 hours. That’s not much time in the grand scheme of things. Immersion leads to progress.

- It’s not about the light at the end of the tunnel. It’s the tunnel. Show up every day and enjoy the process.

- Journaling for at least fifteen to thirty minutes is one of the most powerful forms of self care and therapy.

- You’ll never get what you don’t ask for or actively seek out. Go for it!

- Don’t expect to achieve very much if you spend your life trying to please others.

- Good physical and mental health is the single most valuable thing in the world. It starts with a good diet, regular exercise and ample sleep (7–8 hours).

- Long walks in nature are amazing for processing thoughts, emotions and important decisions.

- The best investment you can make is your own education. Never stop learning. The second best investment you can make is building your network through authentic and meaningful interactions. It is what you know and who you know.

- Sometimes you need to slow down to speed up or go backwards to move forward.

- Forgiving and making amends are brave and powerful acts that can help you turn the page and begin to move forward.

- Life isn’t perfect for everyone but we all have the freedom to choose how we respond to our circumstances. Don’t underestimate the power of faith, hope and positivity.
