# Provision Fresh Arch Install

### 1Password

```sh
curl -sS https://downloads.1password.com/linux/keys/1password.asc | gpg --import
```

```sh
git clone https://aur.archlinux.org/1password.git
```

```sh
cd 1password
makepkg -si
```

---

### Citrix Receiver

```sh
yay -S icaclient
```

```sh
mkdir -p $HOME/.ICAClient/cache
cp
/opt/Citrix/ICAClient/config/{All_Regions,Trusted_Region,Unknown_Region,canonicalization,regions}.ini $HOME/.ICAClient/
```

---

### Pop-Shell

```sh
sudo pacman -S git typescript make
```

```sh
cd /tmp
git clone https://github.com/pop-os/shell.git
```

```sh
cd shell
make local-install
rm -rf ../shell && cd ~
```

```sh
gsettings --schemadir ~/.local/share/gnome-shell/extensions/pop-shell@system76.com/schemas set org.gnome.shell.extensions.pop-shell activate-launcher "['<Super>space']"
```

---

### Node Version Switcher

```sh
export NVS_HOME="$HOME/.nvs"
git clone https://github.com/jasongin/nvs "$NVS_HOME"
. "$NVS_HOME/nvs.sh" install
```

```sh
nvs add latest
```

```sh
nvs use lts
PATH += ~/.nvs/node/6.9.1/x64
```

```sh
nvs link latest
```

---

### GNS3

```sh
sudo pacman -Syu
yay -S gns3-gui gns3-server dynamips ubridge qt5-svg qt5-websockets python-pip python-pyqt5 python-sip4 python-async_generator python-jinja python-distro python-jsonschema python-aiohttp-cors --noconfirm --needed
```

---

### Need to sort later...

```sh
mkdir -p ~/Projects
mkdir -p ~/Projects/APIs
mkdir -p ~/Projects/Applications
mkdir -p ~/Projects/Certificates
mkdir -p ~/Projects/CiscoLabs
mkdir -p ~/Projects/Docker
mkdir -p ~/Projects/DotNet
mkdir -p ~/Projects/Flutter
mkdir -p ~/Projects/Github
mkdir -p ~/Projects/Golang
mkdir -p ~/Projects/Images
mkdir -p ~/Projects/JavaScript
mkdir -p ~/Projects/Jupyter
mkdir -p ~/Projects/Knowledgebase
mkdir -p ~/Projects/PowerShell
mkdir -p ~/Projects/Python
mkdir -p ~/Projects/Rust
mkdir -p ~/Projects/Teams
mkdir -p ~/Projects/Terraform
mkdir -p ~/Projects/WebDesign
```

---

```sh
sudo pacman -S github-cli
gh auth login
gh completion --shell zsh
```

---

```sh
sudo pacman -S nvs
export NVS_HOME="$HOME/.nvs"
git clone https://github.com/jasongin/nvs "$NVS_HOME"\
. "$NVS_HOME/nvs.sh" install
nvs add latest
nvs link latest
```

---

```sh
curl -sS https://downloads.1password.com/linux/keys/1password.asc | gpg --import
git clone https://aur.archlinux.org/1password.git
cd 1password
makepkg -si
```

---

```sh
yay -S icaclient
mkdir -p $HOME/.ICAClient/cache
cp /opt/Citrix/ICAClient/config/{All_Regions,Trusted_Region,Unknown_Region,canonicalization,regions}.ini $HOME/.ICAClient/
```

---

```sh
sudo pacman -S git typescript make
cd /tmp
git clone https://github.com/pop-os/shell.git
cd shell
make local-install
rm -rf ../shell && cd ~
```

---

```sh
paru -S nvs\
icaclient\
gnome-shell-extension-impatience\
gnome-shell-extension-hidetopbar-git\
gnome-shell-extension-alphabetical-grid-extension\
```

---

```sh
sudo pacman -S obsidian\
base-devel\
git\
typescript\
make\
openssh\
exa\
bat\
github-cli\
qemu\
virt-manager\
virt-viewer\
dnsmasq\
vde2\
bridge-utils\
openbsd-netcat\
libguestfs\
ebtables\
iptables\
vim
```

---

```sh
export NVS_HOME="$HOME/.nvs"\
git clone https://github.com/jasongin/nvs "$NVS_HOME"\
. "$NVS_HOME/nvs.sh" install
nvs add latest
nvs link latest
node -v
```

---

```sh
mkdir -p ~/Projects\
mkdir -p ~/Projects/APIs\
mkdir -p ~/Projects/Applications\
mkdir -p ~/Projects/Certificates\
mkdir -p ~/Projects/CiscoLabs\
mkdir -p ~/Projects/Docker\
mkdir -p ~/Projects/DotNet\
mkdir -p ~/Projects/Flutter\
mkdir -p ~/Projects/Github\
mkdir -p ~/Projects/Golang\
mkdir -p ~/Projects/Images\
mkdir -p ~/Projects/JavaScript\
mkdir -p ~/Projects/Jupyter\
mkdir -p ~/Projects/Knowledgebase\
mkdir -p ~/Projects/PowerShell\
mkdir -p ~/Projects/Python\
mkdir -p ~/Projects/Rust\
mkdir -p ~/Projects/Teams\
mkdir -p ~/Projects/Terraform\
mkdir -p ~/Projects/WebDesign
```

---

```sh
sudo systemctl enable --now vmware-networks.service
sudo systemctl enable --now vmware-networks.path
sudo systemctl enable --now vmware-usbarbitrator.service
sudo systemctl enable --now vmware-usbarbitrator.path
sudo chmod a+rw /dev/vmnet*
```

---

```sh
cd /tmp
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
chmod +x Miniconda3-latest-Linux-x86_64.sh
zsh Miniconda3-latest-Linux-x86_64.sh
conda config --set auto_activate_base false\
conda config --set auto_activate_base false\
conda init zsh
eval "$(/home/jodis/miniconda3/bin/conda shell.YOUR_SHELL_NAME hook)"\
eval "$(/home/jodis/miniconda3/bin/conda shell.zsh hook)"\
conda config --set auto_activate_base false\
conda init zsh
rm Miniconda3-latest-Linux-x86_64.sh
```

---

```sh
sudo pacman -Syu
sudo pacman -S qemu virt-manager virt-viewer dnsmasq vde2 bridge-utils openbsd-netcat libguestfs ebtables iptables vim
sudo systemctl enable --now libvirtd.service
sudo echo 'unix_sock_rw_perms = "0770"' | sudo tee -a /etc/libvirt/libvirtd.conf.test
sudo echo 'unix_sock_group = "libvirt"' | sudo tee -a /etc/libvirt/libvirtd.conf.test
cat /etc/libvirt/libvirtd.conf.test
sudo usermod -a -G libvirt $(whoami)\
newgrp libvirt\
sudo systemctl restart libvirtd.service\
sudo modprobe -r kvm_amd\
sudo modprobe kvm_amd nested=1
echo "options kvm-amd nested=1" | sudo tee /etc/modprobe.d/kvm-amd.conf\
sudo cat /etc/modprobe.d/kvm-amd.conf
systool -m kvm_amd -v | grep nested
cat /sys/module/kvm_amd/parameters/nested
systool -m kvm_amd -v | grep nested
```

---

```sh
paru
sudo pacman -S base-devel --needed
sudo pacman -S git typescript make
cd /tmp\
git clone https://github.com/pop-os/shell.git
cd shell\
make local-install
rm -rf ../shell
cd ~
```

---

```sh
ZSH_CUSTOM="$HOME/.config/zsh_custom"\
mkdir -p .config/zsh_custom\
git clone https://github.com/romkatv/powerlevel10k.git $ZSH_CUSTOM/themes/powerlevel10k\
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting\
git clone https://github.com/zsh-users/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions\
exit
```